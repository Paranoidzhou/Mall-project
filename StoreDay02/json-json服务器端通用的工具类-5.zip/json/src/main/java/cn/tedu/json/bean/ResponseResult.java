package cn.tedu.json.bean;

//ResponseResult<T> rr = 
//	new ResponseResult<Void>

//state=1;message="成功";

//ResponseResult<User> rr = 
//new ResponseResult<User>

//state=1;message="成功";
//user=[王影,16];

//ResponseResult<List<City>> rr = 
//new ResponseResult<List<City>>

//state=1;message = "成功";
//list=[{,},{,}]

public class ResponseResult<T> {
	private  Integer state;
	private String message;
	private T data;
	public ResponseResult() {
		
	}
	public ResponseResult(Integer state,
						  String message) {
		super();
		this.state = state;
		this.message = message;
	}
	public ResponseResult(Integer state, String message, T data) {
		super();
		this.state = state;
		this.message = message;
		this.data = data;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	

}










