package cn.tedu.json.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.tedu.json.bean.ResponseResult;
import cn.tedu.json.bean.User;

@Controller
@RequestMapping("/user")
public class UserController {
	
	//返回状态码和信息内容
	@RequestMapping("/test1.do")
	@ResponseBody
	public ResponseResult<Void> test1(){
		ResponseResult<Void> rr =
			new ResponseResult<Void>(1,"成功");
		return rr;
	}
	//返回包含实体类对象的ResponseResult对象
	@RequestMapping("/test2.do")
	@ResponseBody
	public ResponseResult<User> test2(){
		ResponseResult<User> rr = 
			new ResponseResult<User>(1,"成功");
		User user = new User();
		user.setName("王影");
		user.setEmail("wangying@tedu.cn");
		user.setPhone("13800138000");
		
		rr.setData(user);
		
		return rr;
	}
	//响应ResponseResult对象中包含集合类型的数据
	@RequestMapping("/test3.do")
	@ResponseBody
	public ResponseResult<List<User>> test3(){
		ResponseResult<List<User>> rr = 
			new ResponseResult<List<User>>(1,"成功");
		User u1 = new User();
		u1.setName("admin");
		u1.setEmail("admin@tedu.cn");
		u1.setPhone("10086");
		
		User u2 = new User();
		u2.setName("manager");
		u2.setEmail("manager@tedu.cn");
		u2.setPhone("10086");
		
		List<User> list = new ArrayList<User>();
		list.add(u1);
		list.add(u2);
		
		rr.setData(list);
		
		return rr;
		
	}
}
















