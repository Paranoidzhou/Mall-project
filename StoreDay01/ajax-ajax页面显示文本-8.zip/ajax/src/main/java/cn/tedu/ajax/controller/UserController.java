package cn.tedu.ajax.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/user")
public class UserController {
	//显示页面
	@RequestMapping("/showRegister.do")
	public String showRegister(){
		return "register";
	}
	//验证用户名
	//@ResponseBody表示不响应视图组件
	@RequestMapping("/checkName.do")
	@ResponseBody
	public String checkName(String name){
		System.out.println(name);
		if("admin".equals(name)){
			//0表示失败的状态码
			return "0";
		}else{
			//1表示成功的状态码
			return "1";
		}
	}
}







