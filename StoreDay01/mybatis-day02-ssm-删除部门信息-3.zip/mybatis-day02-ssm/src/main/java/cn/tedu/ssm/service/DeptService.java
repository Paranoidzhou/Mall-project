package cn.tedu.ssm.service;

import java.util.List;

import cn.tedu.ssm.bean.Dept;

public interface DeptService {
	/**
	 * 添加部门信息
	 * @param dept
	 */
	void addDept(Dept dept);
	/**
	 * 获取所有部门信息
	 * @return
	 */
	List<Dept> getDeptAll();
	/**
	 * 根据id删除部门信息
	 * @param id
	 */
	void removeById(Integer id);

}
