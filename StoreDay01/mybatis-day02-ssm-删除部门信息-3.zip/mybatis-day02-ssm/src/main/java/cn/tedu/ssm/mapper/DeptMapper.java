package cn.tedu.ssm.mapper;

import java.util.List;

import cn.tedu.ssm.bean.Dept;

public interface DeptMapper {
	/**
	 * 插入部门信息
	 * @param dept
	 */
	void insertDept(Dept dept);
	/**
	 * 查询所有部门信息
	 * @return
	 */
	List<Dept> selectAll();
	/**
	 * 根据id删除部门信息
	 * @param id
	 */
	void deleteById(Integer id);
	
}





