package test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.tedu.ssm.bean.Dept;
import cn.tedu.ssm.mapper.DeptMapper;
import cn.tedu.ssm.service.DeptService;

public class TestDept {
	
	@Test
	public void testDelById(){
		//1.获取spring容器
		ApplicationContext ac =
					new ClassPathXmlApplicationContext(
							"spring-mybatis.xml");
		/*DeptMapper dm = 
				ac.getBean("deptMapper",DeptMapper.class);	
		dm.deleteById(1);*/
		DeptService ds 
			= ac.getBean("deptServiceImpl",DeptService.class);
		ds.removeById(2);
	}
	@Test
	public void testGetAll(){
		//1.获取spring容器
		ApplicationContext ac =
						new ClassPathXmlApplicationContext(
								"spring-mybatis.xml");
		DeptService ds = 
				ac.getBean("deptServiceImpl",DeptService.class);
		System.out.println(
				ds.getDeptAll());
	}
	@Test
	public void testSelect(){
		//1.获取spring容器
		ApplicationContext ac =
				new ClassPathXmlApplicationContext(
								"spring-mybatis.xml");
		DeptMapper dm = 
				ac.getBean("deptMapper",DeptMapper.class);
		List<Dept> list = dm.selectAll();
		System.out.println(list);
	}
	@Test
	public void testAdd(){
		//1.获取spring容器
		ApplicationContext ac =
				new ClassPathXmlApplicationContext(
						"spring-mybatis.xml");
		//2.获取业务层对象
		DeptService ds =
				ac.getBean("deptServiceImpl",
						    DeptService.class);
		Dept dept = new Dept();
		dept.setDeptName("教学部");
		dept.setDeptLoc("中鼎大厦7层");
		ds.addDept(dept);
	}
	@Test
	public void testInsert(){
		//1.获取spring容器
		ApplicationContext ac =
		new ClassPathXmlApplicationContext(
				"spring-mybatis.xml");
		//2.获取DeptMapper对象
		DeptMapper dm = 
		ac.getBean("deptMapper",DeptMapper.class);
		Dept dept = new Dept();
		dept.setDeptName("第一开发部");
		dept.setDeptLoc("中鼎大厦8层18");
		dm.insertDept(dept);
	}
}








