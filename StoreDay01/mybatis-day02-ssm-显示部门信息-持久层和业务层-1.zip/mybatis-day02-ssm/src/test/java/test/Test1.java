package test;

import org.junit.Test;
import org.springframework.web.servlet.DispatcherServlet;

public class Test1 {
	@Test
	public void test(){
		DispatcherServlet ds = null;
	}
}
