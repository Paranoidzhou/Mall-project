package cn.tedu.ssm.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.tedu.ssm.bean.Dept;
import cn.tedu.ssm.mapper.DeptMapper;
//实例化业务层对象
@Service
public class DeptServiceImpl 
				implements DeptService{
	//依赖注入
	@Resource
	private DeptMapper deptMapper;
	public void addDept(Dept dept) {
		//调用持久层的方法
		deptMapper.insertDept(dept);
		
	}
	public List<Dept> getDeptAll() {
	
		return deptMapper.selectAll();
	}

}
