package cn.tedu.ajax.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserController {
	//显示页面
	@RequestMapping("/showRegister.do")
	public String showRegister(){
		return "register";
	}
	//验证用户名
}







