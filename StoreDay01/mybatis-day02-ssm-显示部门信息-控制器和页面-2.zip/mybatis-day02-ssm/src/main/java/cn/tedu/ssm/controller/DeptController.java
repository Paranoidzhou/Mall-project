package cn.tedu.ssm.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.tedu.ssm.bean.Dept;
import cn.tedu.ssm.service.DeptService;
//@Controller实例化控制器
//@RequestMapping("/dept")表示定义
//	模块的名称(二级路径)
@Controller
@RequestMapping("/dept")
public class DeptController {
	//依赖 注入业务层对象
	@Resource
	private DeptService deptService;
	//@RequestMapping("/showAdd.do")定义映射名
	@RequestMapping("/showAdd.do")
	public String showAdd(){
		return "add";
	}
	//提交按钮的提交事件
	@RequestMapping("/addDept.do")
	public String addDept(
			String name,String loc){
		//1.调用业务层方法
		Dept dept = new Dept();
		dept.setDeptName(name);
		dept.setDeptLoc(loc);
		deptService.addDept(dept);
		return "ok";
	}
	@RequestMapping("/getAll.do")
	public String getAll(ModelMap map){
		//1.调用业务层方法,返回list
		List<Dept> list = 
				deptService.getDeptAll();
		//2.把list添加到map
		map.addAttribute("list",list);
		//3.showDept表示显示页面:shoeptwD.jsp
		return "showDept";
	}
}








